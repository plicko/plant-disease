<!--
 1. IF YOU DON'T FILL OUT THE FOLLOWING INFORMATION WE MAY CLOSE YOUR ISSUE WITHOUT INVESTIGATION
 2. SEARCH EXISTING ISSUES FOR AN ANSWER: https://goo.gl/G4XxN2
 3. See our Common Issues documentation: https://goo.gl/N6VDpg
 4. See our contributing guidelines: https://goo.gl/qE6wSg
-->

**Description:**
<!-- (write below this line) -->

(your description here)

**Environment**
<!-- Example:
1. What version of the Cordova SDK are you using?
2. Provide a list of your project dependencies (using `cordova plugin list` or copy-pasting your config.xml)
 -->



**Steps to Reproduce Issue:**
<!--
  Example:

  1. Add the onesignal-cordova-plugin to your project
  2. Initialize the plugin with your app ID
  3. Attempt to receive a push notification

  (write below this line) -->

1. (your steps here)
2.
3.

**Anything else:**

(crash stacktraces, as well as any other information here)


<!--
  SEARCH EXISTING ISSUES FOR AN ANSWER: https://goo.gl/G4XxN2
-->
