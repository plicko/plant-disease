import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'deasese-show-indetail',
  templateUrl: './deasese-show-indetail.page.html',
  styleUrls: ['./deasese-show-indetail.page.scss'],
})
export class DeaseseShowIndetailPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
