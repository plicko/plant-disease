import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'share',
  templateUrl: './share.page.html',
  styleUrls: ['./share.page.scss'],
})
export class SharePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
