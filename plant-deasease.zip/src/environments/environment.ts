
export const environment = {
  production: true,
  // firebase: {
  //   apiKey: "AIzaSyB1io7IUDLmU2vvJyWVEvAV3pAwoPVtYO8",
  //   authDomain: "corona-231ac.firebaseapp.com",
  //   databaseURL: "https://corona-231ac.firebaseio.com",
  //   projectId: "corona-231ac",
  //   storageBucket: "corona-231ac.appspot.com",
  //   messagingSenderId: "76151864937",
  //   appId: "1:76151864937:web:5a2eadc394e2e870376cf8"
  // }
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
