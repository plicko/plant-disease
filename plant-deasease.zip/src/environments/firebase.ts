
export const firebase = {
  apiKey: "AIzaSyAjLrGM4biJ8as1QNpFVgj7L3mRDDaF6r0",
  authDomain: "plant-deasease.firebaseapp.com",
  databaseURL: "https://plant-deasease.firebaseio.com",
  projectId: "plant-deasease",
  storageBucket: "plant-deasease.appspot.com",
  messagingSenderId: "302269933403",
  appId: "1:302269933403:web:119101de3081c05332dc7e"
    }
  
  /*
   * For easier debugging in development mode, you can import the following file
   * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
   *
   * This import should be commented out in production mode because it will have a negative impact
   * on performance if an error is thrown.
   */
  // import 'zone.js/dist/zone-error';  // Included with Angular CLI.
  